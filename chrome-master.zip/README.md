# Drupal API Search
[![endorse](https://api.coderwall.com/carwin/endorsecount.png)](https://coderwall.com/carwin)

This extension for Google Chrome provides a way to search the
[Drupal API](http://api.drupal.org) from the omnibar.

## Usage

 1. Type `dapi` into the omnibar then hit `tab` or `space` to
    initialize the extension.
 2. Type your search query and press `Enter`/`Return` to search.

 __Suggestions are currently unsupported. See issue #1.__
