
cp = {}

cp.notification = function(obj){
    if ('Notification' in window) {
        window.notification = new Notification(obj.title, {
            body: obj.body,
            icon: obj.icon,
            tag: obj.tag,
        });
    }
}

cp.getData = function(){
    $.post("https://www.numberbazaar.com/recharge/count", {},
        function(data, e, d) {

            if (data.total == 0) {

                // $.post('https://www.numberbazaar.com/recharge/login', {
                //     userid: username,
                //     password: password
                // });

                window.random = window.random || Math.random();

                cp.notification({
                    title: 'numberbazaar',
                    body: 'Please login to "www.numberbazaar.com/recharge/dashboardview" to enable recharge notifications.',
                    icon: 'icon.png',
                    tag: window.random
                });


            } else {

                if(data.inque == 0) return false;

                cp.notification({
                    title: 'recharge',
                    body: data.inque+' recharge(s) inqueue.\ntoday: '+data.todaycount,
                    icon: data.inque+'.fw.png',
                    tag: data.inque+''+data.todaycount
                });
                
            }

        }, 'json').error(function(e, d, f) {

            if(e.status == 0){
                cp.notification({
                    title: 'Cannot connect!',
                    body: 'Cannot connect to the internet, please check your internet connection.',
                    icon: 'icon.png',
                    tag: window.random
                });
            }            

        })
};

setInterval(function() {
    cp.getData();
}, 2000);